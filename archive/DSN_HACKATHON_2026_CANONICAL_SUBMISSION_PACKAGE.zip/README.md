# DSN Bootcamp Qualification Hackathon 2026 ML Track
## Final Competition Release / Reproducibility Package

**Release Date:** 2026-09-22  
**Status:** FROZEN  
**Canonical SHA256:** `55f346a2d7a94e10f83cf5e393013a113d74210ab128ce95dd89501277c354e4`

---

## Overview

This package contains the complete final release artifacts for the DSN Bootcamp Qualification Hackathon 2026 ML Track. It includes:

- Two final submission options with verified hashes and public scores
- Exact reproduction scripts for both submissions
- Provenance records and integrity checks
- Complete reproducibility certificate
- Research history and archival manifests

**No new Kaggle submissions are authorized by this package.**

---

## Final Submission Options

### OPTION_1_CANONICAL (Primary)

| Field | Value |
|-------|-------|
| File | `submissions/OPTION_1_CANONICAL/FINAL_SUBMISSION.csv` |
| SHA256 | `55f346a2d7a94e10f83cf5e393013a113d74210ab128ce95dd89501277c354e4` |
| Public Score | 1073.18868 |
| Reproducibility | BYTE-IDENTICAL |

**Script:** `code/canonical/reproduce_canonical.py`  
**Authoritative source:** `ARCHIVE/FINAL_ARCHIVE_ORIG/temporary_files/_exec_notebook.py`

### OPTION_2_E3_HEDGE (Alternate)

| Field | Value |
|-------|-------|
| File | `submissions/OPTION_2_E3/PHASE11C_SHADOW_SUBMISSION_E3.csv` |
| SHA256 | `8805c96e3411acc154429e6b8376446e8bfdff75ba453e1c05ed534373f4f962` |
| Public Score | 1084.00044 |
| Reproducibility | BYTE-IDENTICAL (CatBoost 1.2.10 required) |

**Script:** `code/e3/reproduce_e3.py`  
**Authoritative source:** `ARCHIVE/REPORTS/PHASE11C_production_train.py`

---

## Package Structure

```
FINAL_RELEASE/
├── README.md
├── SUBMISSION_OPTIONS.md
├── REPRODUCIBILITY_CERTIFICATE.md
├── RELEASE_MANIFEST.csv
├── HASH_MANIFEST.sha256
├── FINAL_RELEASE_CHECKLIST.md
├── FINAL_RELEASE_AUDIT.md
├── GIT_STATE.md
├── CANONICAL_PIPELINE_TRACE.md
├── E3_PIPELINE_TRACE.md
├── submissions/
│   ├── OPTION_1_CANONICAL/
│   │   ├── FINAL_SUBMISSION.csv
│   │   ├── provenance.json
│   │   └── hash.txt
│   └── OPTION_2_E3/
│       ├── PHASE11C_SHADOW_SUBMISSION_E3.csv
│       ├── provenance.json
│       └── hash.txt
├── code/
│   ├── canonical/
│   │   └── reproduce_canonical.py
│   └── e3/
│       └── reproduce_e3.py
├── notebooks/
│   ├── canonical_reproduction.ipynb
│   └── e3_reproduction.ipynb
├── reports/
│   ├── FINAL_RESEARCH_REPORT.md
│   ├── REPRODUCIBILITY_REPORT.md
│   └── PHASE23_CLOSURE.md
├── research_history/
│   ├── phase19/
│   ├── phase23/
│   └── archived_candidates/
└── environment/
    ├── requirements.txt
    ├── environment.yml
    └── python_version.txt
```

---

## Verification

All submission files have been verified for:
- Correct schema (`id`, `total_sales`)
- Correct row count (1705)
- No duplicate IDs
- No missing IDs
- No NaN / Inf values
- ID order matches sample submission
- SHA256 hash integrity

Canonical submission is frozen. Do not modify.

---

## Known Limitations

1. E3 requires CatBoost 1.2.10 exactly for byte-identical reproduction
2. E3 script must run from ARCHIVE/REPORTS/ for relative paths
3. Private leaderboard performance is unknown for both options
4. No new experiments or submissions are authorized

---

*Package generated as part of FINAL COMPETITION RELEASE / REPRODUCIBILITY WAR ROOM.*
