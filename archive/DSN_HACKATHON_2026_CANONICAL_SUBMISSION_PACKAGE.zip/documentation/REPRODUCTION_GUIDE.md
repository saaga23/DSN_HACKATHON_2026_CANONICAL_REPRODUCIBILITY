# REPRODUCTION_GUIDE.md

## 1. Required competition data (supplied separately)

This package does NOT include competition data. You must supply:

- `train.csv` — training data with target `total_sales`
- `test.csv` — test data (1,705 rows)
- `sample_submission.csv` — schema reference

Place these files in a `competition_data/` directory adjacent to the package,
or pass `--data-dir` to the reproduction script.

## 2. Reproduce OPTION_1_CANONICAL

Reproduction script: `code/canonical/reproduce_canonical.py`
Notebook: `notebooks/canonical_reproduction.ipynb`

```powershell
python code/canonical/reproduce_canonical.py --data-dir ../DATA/competition_data --output-dir submission
```

Expected output: `submission/FINAL_SUBMISSION.csv`
Expected SHA256: `55f346a2d7a94e10f83cf5e393013a113d74210ab128ce95dd89501277c354e4`

## 3. Reproduce OPTION_2_E3

Reproduction script: `code/e3/reproduce_e3.py`
Notebook: `notebooks/e3_reproduction.ipynb`

```powershell
python code/e3/reproduce_e3.py --data-dir ../DATA/competition_data --output-dir submission
```

Expected output: `submission/PHASE11C_SHADOW_SUBMISSION_E3.csv`
Expected SHA256: `8805c96e3411acc154429e6b8376446e8bfdff75ba453e1c05ed534373f4f962`

**Critical:** E3 reproduction requires CatBoost 1.2.10 exactly for
byte-identical results. BYTE-IDENTICAL reproduction was VERIFIED across
two independent clean processes using CatBoost 1.2.10.

## 4. Verify submission hash

```powershell
Get-FileHash -Algorithm SHA256 "submission/FINAL_SUBMISSION.csv"
Get-FileHash -Algorithm SHA256 "submission/PHASE11C_SHADOW_SUBMISSION_E3.csv"
```

## 5. Notes

- `folds_seed42.csv` is NOT included in this package. The canonical
  reproduction script will deterministically regenerate it if missing.
- Do NOT claim artifacts not present in this package are included.
- Do NOT modify frozen submission files.
