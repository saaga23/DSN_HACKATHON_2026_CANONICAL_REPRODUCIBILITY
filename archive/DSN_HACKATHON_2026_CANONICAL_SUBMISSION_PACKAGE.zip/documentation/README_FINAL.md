# Competition

DSN Bootcamp Qualification Hackathon 2026 ML Track

## Authoritative Submission

FINAL_SUBMISSION.csv

## Public Score

1073.18868

## SHA256

55f346a2d7a94e10f83cf5e393013a113d74210ab128ce95dd89501277c354e4

## Current Status

Submission frozen. No new submission authorized.

## Research Status

Phases completed through Phase 18. Phase 18 ensemble branch closed.

## Important Rejected Candidate

Phase 11 E3: 1084.00044 public RMSE � REJECTED.

## Reproduction

Authoritative reproduction artifacts: see FINAL_RELEASE/reproduction/ and ARCHIVE/PHASES/.

## Archive

All historical research is under ARCHIVE/.
